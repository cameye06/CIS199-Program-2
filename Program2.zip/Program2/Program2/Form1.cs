﻿/* 
 * B8426
 * CIS 199
 * Section 02
 * Program 2
 * due: 3/9/2017
 * 
 * this program asks you to enter your last initial and choose your current class standing
 * then, using info from http://louisville.edu/registrar/registration-information/prisummer
 * to give you your registration date and time
 * 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void getButton_Click(object sender, EventArgs e) // getButton click event
        {
            //lastIn stands for last initial
            string name = lastInBox.Text.ToUpper(); // sets the text in lastInBox to all caps then sets it to string 'name'
            char lastIn; //creates a char named lastIn
            if (name.Length>0) //checks to make sure that there is something writen in lastinbox
            {
                lastIn = name[0]; //sets lastIn to the first letter entered into name
                
                if ( char.IsLetter(lastIn)) //checks to see that they entered a letter and not a number or character
                {
                  
                    if (senior.Checked || junior.Checked) // if senior or junior radio buttons are checked
                        //it sets the timeLable based on lastIn
                    {
                        if (lastIn <='D')//checks to see if lastIn is <= 'D'
                        { timeLable.Text = ("11:30");} //sets timeLable
                        else if (lastIn <='I') // <'D' <=I
                        { timeLable.Text = "2:00";} //sets timeLable
                        else if (lastIn <= 'O') // <'I' <='O'
                        { timeLable.Text = "4:00";}// sets timeLable
                        else if (lastIn <= 'S')// <'O' <='S'
                        { timeLable.Text = "8:30"; }//sets timeLable
                        else if (lastIn <= 'Z')// <'S' <='Z'
                        { timeLable.Text = "10:00"; }//sets timeLable

                        if (senior.Checked) {dateLable.Text = "March 29";} // if senior is checked the dateLable will be March 29
                        else {dateLable.Text = "March 30"; } // if junior is checked then dateLable is march 30
                    }

                    else if (sophomore.Checked || freshman.Checked) // if sophomre or freshman are checked
                    {
                        if (lastIn <= 'B') // same as before. checks to see if lastIn is <=B
                        { timeLable.Text = ("4:00"); } // sets the corresponding time
                        else if (lastIn <= 'D')// <'B' <='D'
                        { timeLable.Text = ("8:30"); }// sets the corresponding time
                        else if (lastIn <= 'F')// <'D' <='F'
                        { timeLable.Text = ("10:00"); }// sets the corresponding time
                        else if (lastIn <= 'I')// <'F' <='I'
                        { timeLable.Text = ("11:30"); }// sets the corresponding time
                        else if (lastIn <= 'L')// <'I' <='L'
                        { timeLable.Text = ("2:00"); }// sets the corresponding time
                        else if (lastIn <= 'O')// <'D' <='O'
                        { timeLable.Text = ("4:00"); }// sets the corresponding time
                        else if (lastIn <= 'Q')// <'O' <='Q'
                        { timeLable.Text = ("8:30"); }// sets the corresponding time
                        else if (lastIn <= 'S')// <'Q' <='S'
                        { timeLable.Text = ("10:00"); }// sets the corresponding time
                        else if (lastIn <= 'V')// <'S' <='V'
                        { timeLable.Text = ("11:30"); }// sets the corresponding time
                        else if (lastIn <= 'Z')// <'v' <='Z'
                        { timeLable.Text = ("2:00"); }// sets the corresponding time

                        if (sophomore.Checked) //if sophomore is checked
                        {
                            if(lastIn <= 'O' && lastIn != 'A' && lastIn != 'B') // if less than 'O' and not A or B the date is april 2
                            {
                                dateLable.Text = "April 3"; 
                            }
                            else { dateLable.Text = "March 31";} // else it is march 31
                        }
                        if (freshman.Checked)
                        {
                            if (lastIn <= 'O' && lastIn != 'A' && lastIn != 'B')// if less than 'O' and not A or B the date is april 5
                            {
                                dateLable.Text = "April 5";
                            }
                            else { dateLable.Text = "April 4"; } // else it is arpril 4
                        }

                    } else { MessageBox.Show("you did not select a year!"); } // prints if no radio buttons are selected
                }else { MessageBox.Show("you must enter a letter or a name!"); } // prints if a number or symbol is enterd
            }else { MessageBox.Show("you did not enter anything!");} // prints if nothing is enterd
        }
    }
}
