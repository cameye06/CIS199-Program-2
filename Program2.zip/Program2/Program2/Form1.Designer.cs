﻿namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.getButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.freshman = new System.Windows.Forms.RadioButton();
            this.sophomore = new System.Windows.Forms.RadioButton();
            this.junior = new System.Windows.Forms.RadioButton();
            this.senior = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.timeLable = new System.Windows.Forms.Label();
            this.dateLable = new System.Windows.Forms.Label();
            this.lastInBox = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // getButton
            // 
            this.getButton.AutoSize = true;
            this.getButton.Location = new System.Drawing.Point(105, 237);
            this.getButton.Name = "getButton";
            this.getButton.Size = new System.Drawing.Size(154, 37);
            this.getButton.TabIndex = 0;
            this.getButton.Text = "Get Date and Time";
            this.getButton.UseVisualStyleBackColor = true;
            this.getButton.Click += new System.EventHandler(this.getButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Last Initial:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(80, 388);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Time:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(80, 324);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Date:";
            // 
            // freshman
            // 
            this.freshman.AutoSize = true;
            this.freshman.Location = new System.Drawing.Point(6, 30);
            this.freshman.Name = "freshman";
            this.freshman.Size = new System.Drawing.Size(106, 24);
            this.freshman.TabIndex = 5;
            this.freshman.TabStop = true;
            this.freshman.Text = "Freshman";
            this.freshman.UseVisualStyleBackColor = true;
            // 
            // sophomore
            // 
            this.sophomore.AutoSize = true;
            this.sophomore.Location = new System.Drawing.Point(6, 60);
            this.sophomore.Name = "sophomore";
            this.sophomore.Size = new System.Drawing.Size(117, 24);
            this.sophomore.TabIndex = 6;
            this.sophomore.TabStop = true;
            this.sophomore.Text = "Sophomore";
            this.sophomore.UseVisualStyleBackColor = true;
            // 
            // junior
            // 
            this.junior.AutoSize = true;
            this.junior.Location = new System.Drawing.Point(6, 90);
            this.junior.Name = "junior";
            this.junior.Size = new System.Drawing.Size(77, 24);
            this.junior.TabIndex = 7;
            this.junior.TabStop = true;
            this.junior.Text = "Junior";
            this.junior.UseVisualStyleBackColor = true;
            // 
            // senior
            // 
            this.senior.AutoSize = true;
            this.senior.Location = new System.Drawing.Point(6, 120);
            this.senior.Name = "senior";
            this.senior.Size = new System.Drawing.Size(80, 24);
            this.senior.TabIndex = 8;
            this.senior.TabStop = true;
            this.senior.Text = "Senior";
            this.senior.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.junior);
            this.groupBox1.Controls.Add(this.senior);
            this.groupBox1.Controls.Add(this.freshman);
            this.groupBox1.Controls.Add(this.sophomore);
            this.groupBox1.Location = new System.Drawing.Point(84, 63);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 168);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Class Standing";
            // 
            // timeLable
            // 
            this.timeLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.timeLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timeLable.Location = new System.Drawing.Point(138, 376);
            this.timeLable.Name = "timeLable";
            this.timeLable.Size = new System.Drawing.Size(147, 45);
            this.timeLable.TabIndex = 10;
            // 
            // dateLable
            // 
            this.dateLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dateLable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateLable.Location = new System.Drawing.Point(138, 312);
            this.dateLable.Name = "dateLable";
            this.dateLable.Size = new System.Drawing.Size(147, 45);
            this.dateLable.TabIndex = 11;
            // 
            // lastInBox
            // 
            this.lastInBox.Location = new System.Drawing.Point(170, 18);
            this.lastInBox.Name = "lastInBox";
            this.lastInBox.Size = new System.Drawing.Size(114, 26);
            this.lastInBox.TabIndex = 12;
            // 
            // Form1
            // 
            this.AcceptButton = this.getButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 450);
            this.Controls.Add(this.lastInBox);
            this.Controls.Add(this.dateLable);
            this.Controls.Add(this.timeLable);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.getButton);
            this.Name = "Form1";
            this.Text = "Program2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button getButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton freshman;
        private System.Windows.Forms.RadioButton sophomore;
        private System.Windows.Forms.RadioButton junior;
        private System.Windows.Forms.RadioButton senior;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label timeLable;
        private System.Windows.Forms.Label dateLable;
        private System.Windows.Forms.TextBox lastInBox;
    }
}

